from django.db import models

class Lead(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=20)
    address = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    state = models.CharField(max_length=100, blank=True, null=True)
    zip = models.CharField(max_length=10, blank=True, null=True)
    company_name = models.CharField(max_length=255, blank=True, null=True)
    position = models.CharField(max_length=100, blank=True, null=True)
    budget = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    company_address = models.CharField(max_length=255, blank=True, null=True)
    company_city = models.CharField(max_length=100, blank=True, null=True)
    company_state = models.CharField(max_length=100, blank=True, null=True)
    company_zip = models.CharField(max_length=10, blank=True, null=True)
    urgency = models.CharField(max_length=50, choices=[('immediate', 'Immediate'), ('short-term', 'Short-Term'), ('long-term', 'Long-Term')], blank=True, null=True)
    hear_about_us = models.CharField(max_length=50, choices=[('google', 'Google'), ('facebook', 'Facebook'), ('linkedin', 'LinkedIn'), ('twitter', 'Twitter'), ('instagram', 'Instagram'), ('friend', 'Friend'), ('visit', 'Personal Visit')], blank=True, null=True)
    requirement = models.TextField(blank=True, null=True)
    consent = models.BooleanField(default=False)

    def __str__(self):
        return self.name

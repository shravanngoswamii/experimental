from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('add/', views.add_lead, name='add_lead'),
    path('edit/<int:lead_id>/', views.edit_lead, name='edit_lead'),
]

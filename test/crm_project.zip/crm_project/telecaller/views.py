from django.shortcuts import render, redirect, get_object_or_404
from .models import Lead
from .forms import LeadForm

def add_lead(request):
    if request.method == 'POST':
        form = LeadForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    else:
        form = LeadForm()
    return render(request, 'telecaller/add_lead.html', {'form': form})

def edit_lead(request, lead_id):
    lead = get_object_or_404(Lead, id=lead_id)
    if request.method == 'POST':
        form = LeadForm(request.POST, instance=lead)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    else:
        form = LeadForm(instance=lead)
    return render(request, 'telecaller/edit_lead.html', {'form': form, 'lead': lead})

def dashboard(request):
    leads = Lead.objects.all()
    return render(request, 'telecaller/dashboard.html', {'leads': leads})

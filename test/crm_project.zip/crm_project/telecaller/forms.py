from django import forms
from .models import Lead

class LeadForm(forms.ModelForm):
    class Meta:
        model = Lead
        fields = '__all__'
        widgets = {
            'urgency': forms.Select(choices=[
                ('immediate', 'Immediate'),
                ('short-term', 'Short-Term'),
                ('long-term', 'Long-Term')
            ]),
            'hear_about_us': forms.Select(choices=[
                ('google', 'Google'),
                ('facebook', 'Facebook'),
                ('linkedin', 'LinkedIn'),
                ('twitter', 'Twitter'),
                ('instagram', 'Instagram'),
                ('friend', 'Friend'),
                ('visit', 'Personal Visit')
            ]),
            'consent': forms.CheckboxInput(),
        }
        labels = {
            'name': 'Name',
            'phone': 'Phone',
            'email': 'Email',
            'address': 'Address',
            'city': 'City',
            'state': 'State',
            'zip': 'Pin Code',
            'company_name': 'Company Name',
            'position': 'Position',
            'budget': 'Budget in INR',
            'company_address': 'Company Address',
            'company_city': 'Company City',
            'company_state': 'Company State',
            'company_zip': 'Company Pin Code',
            'urgency': 'Urgency',
            'hear_about_us': 'How did you hear about us?',
            'requirement': 'Any Specific Requirement',
            'consent': 'I consent to being contacted for follow-up or future communication.',
        }

    def __init__(self, *args, **kwargs):
        super(LeadForm, self).__init__(*args, **kwargs)
        self.fields['name'].required = True
        self.fields['phone'].required = True
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})
